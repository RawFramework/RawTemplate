﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
//using System.Runtime.Loader;
using System.Threading.Tasks;

namespace Generator.Helpers
{
    //public class LoadContextHelper : AssemblyLoadContext
    //{

    //    public string AssemblyPath { get; set; }
    //    protected override Assembly Load(AssemblyName assemblyName)
    //    {
    //        string name = Path.Combine(AssemblyPath, assemblyName.Name);
    //        var asFile = new FileStream(name,FileMode.Open);
    //        return base.LoadFromStream(asFile);
    //    }
    //}
}
