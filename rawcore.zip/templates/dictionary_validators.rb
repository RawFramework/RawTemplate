@dictionary_validators = {
	"notEmpty" => "Required",
	"emailAddress" => "Email",
	"max" => "MaxLen"
}