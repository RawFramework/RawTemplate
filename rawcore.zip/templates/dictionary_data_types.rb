@dictionary_data_types = {
	"numeric" => "int",
	"date" => "DateTime"
}